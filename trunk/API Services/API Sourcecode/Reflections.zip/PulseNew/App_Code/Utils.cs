﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jive.BusinessRules
{
    public class Utils
    {
       
    }

    //public static class ReturnType
    //{
    //    public static const string All = "ALL";
    //    public static const string Folder = "FOLDER";
    //    public static const string File = "File";
    //}

}
