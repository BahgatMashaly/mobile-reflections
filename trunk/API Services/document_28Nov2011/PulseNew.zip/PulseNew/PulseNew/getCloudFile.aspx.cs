﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

public partial class getCloudFile : System.Web.UI.Page
{
        protected void Page_Load(object sender, EventArgs e)
        {
            String userid = Request.QueryString["userid"];
            String ticket = Request.QueryString["ticket"];

            if (userid == null || ticket == null)
            {
                Response.Write("");
                return;
            }

            GetData gd = new GetData();

            if (!(gd.validateUserTicket(userid, ticket)))
            {
                Response.Write("");
                return;
            }

            String fpath = Request.QueryString["path"];
            String otheruser = Request.QueryString["otherpath"];
            String fullpath = "";
            if (fpath.StartsWith("Personal") || (otheruser != null && !otheruser.Equals("")))
            {
                if (otheruser != null && !otheruser.Equals(""))
                {
                    // ensure we have permission
                    fullpath = gd.getFilePath() + otheruser;
                }
                else
                {
                    fullpath = gd.getFilePath() + userid + @"\" + fpath.Substring(9);
                }

                if (File.Exists(fullpath))
                {
                    Response.Clear();
                    System.IO.FileInfo fileToDownload = new System.IO.FileInfo(fullpath);
                    string disHeader = "Attachment; Filename=\"" + fileToDownload.Name + "\"";
                    Response.AppendHeader("Content-Disposition", disHeader);
                    Response.Flush();
                    Response.TransmitFile(fileToDownload.FullName);
                }
            }
            else
            {
                string sitename = fpath.Substring(0, fpath.IndexOf(@"\"));
                fullpath = gd.getSiteFilePath() + fpath;
                if (File.Exists(fullpath))
                {
                    Response.Clear();
                    System.IO.FileInfo fileToDownload = new System.IO.FileInfo(fullpath);
                    string disHeader = "Attachment; Filename=\"" + fileToDownload.Name + "\"";
                    Response.AppendHeader("Content-Disposition", disHeader);
                    Response.Flush();
                    Response.TransmitFile(fileToDownload.FullName);
                }
            }
        }

}