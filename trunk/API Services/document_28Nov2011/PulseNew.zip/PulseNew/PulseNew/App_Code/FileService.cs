﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using Jive.BusinessRules;
using System.Data;


/// <summary>
/// Summary description for FileService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class FileService : System.Web.Services.WebService {

        [WebMethod]
        public string TestService()
        {
            return new GetData().TestConnection();
        }

        [WebMethod]
        public string validateUser(string username, string password)
        {
            return new GetData().validateUser(username, password);
        }

        [WebMethod]
        public string getUserInfo(string userid, string ticket)
        {
            return new GetData().getUserInfo(userid, ticket);
        }

        [WebMethod]
        public string getAllFolders(string userid, string ticket, string foldername, string returntype)
        {
            return new GetData().getFolders(userid, ticket, foldername, returntype);
        }

        [WebMethod]
        public string getFolders(string userid, string ticket, string foldername, string returntype)
        {
            return new GetData().getFolders(userid, ticket, foldername, returntype);
        }

        [WebMethod]
        public string createFolder(string userid, string ticket, string folderPath, string folderName)
        {
            return new GetData().createFolder(userid, ticket, folderPath, folderName );
        }

        [WebMethod]
        public string deleteFile(string userId, string ticket, string filepath)
        {
            return new GetData().deleteFile(userId, ticket, filepath);
        }

        [WebMethod]
        public string deleteFolder(string userId, string ticket, string folderpath)
        {
            return new GetData().deleteFolder(userId, ticket, folderpath);
        }

        [WebMethod]
        public string shareResource(string userid, string ticket, string filePath, string otherusers)
        {
            return new GetData().shareResource(userid, ticket, filePath, otherusers);
        }

        [WebMethod]
        public string getAllSharedResource(string userid, string ticket)
        {
            return new GetData().getAllSharedResource(userid, ticket);
        }

        [WebMethod]
        public string copyFile(string userid, string ticket, string srcFile, string destFolder)
        {
            return new GetData().copyFile(userid, ticket, srcFile, destFolder);
        }

        [WebMethod]
        public string moveFile(string userid, string ticket, string srcFile, string destFolder)
        {
            return new GetData().moveFile(userid, ticket, srcFile, destFolder);
        }


        [WebMethod]
        public string copySharedFile(string userid, string ticket, string srcFile)
        {
            return new GetData().copySharedFile(userid, ticket, srcFile);
        }

    /*
        [WebMethod]
        public string getSharedResource(string userid, string ticket, string otheruser, string folder)
        {
            return new GetData().getSharedResource(userid, ticket, otheruser, folder);
        }
     * */

        [WebMethod]
        public string markPrivate(string userid, string ticket, string reflectionid)
        {
            return new GetData().markPrivate(userid, ticket, reflectionid);
        }

        [WebMethod]
        public string getReflectionsSummary(string userid, string ticket, string monthyear, bool isPublic)
        {
            return new GetData().getReflectionsSummary(userid, ticket, monthyear, isPublic);
        }

        [WebMethod]
        public string getReflection(string userid, string ticket, string reflectionid, string ispublic)
        {
            return new GetData().getReflection(userid, ticket, reflectionid, ispublic);
        }

        [WebMethod]
        public string saveReflection(string userid, string ticket, string id, string title, string content, bool isPrivate)
        {
            return new GetData().saveReflection(userid, ticket, id, title, content, isPrivate);
        }

        [WebMethod]
        public string deleteReflection(string userid, string ticket, int reflectionid)
        {
            return new GetData().deleteReflection(userid, ticket, reflectionid);
        }

        [WebMethod]
        public string saveReflectionAttachment(string userid, string ticket, string reflectionid, string name, string guid)
        {
            return new GetData().saveReflectionAttachment(userid, ticket, reflectionid, name, guid);
        }

        [WebMethod]
        public string getReflectionComment(string userid, string ticket, string reflectionid)
        {
            return new GetData().getReflectionComment(userid, ticket, reflectionid);
        }

        [WebMethod]
        public string addReflectionComment(string reflectionid, string reflectioncommentid, string userid, string ticket, string content)
        {
            return new GetData().addReflectionComment(reflectionid, reflectioncommentid, userid, ticket, content);
        }

        [WebMethod]
        public string deleteReflectionComment(string userid, string ticket, string commentid)
        {
            return new GetData().deleteReflectionComment(userid, ticket, commentid);
        }

        [WebMethod]
        public string saveReflectionCommentAttachment(string userid, string ticket, string commentid, string name, string guid)
        {
            return new GetData().saveReflectionCommentAttachment(userid, ticket, commentid, name, guid);
        }

        [WebMethod]
        public string deleteReflectionAttachment(string userid, string ticket, string attachmentid)
        {
            return new GetData().deleteReflectionAttachment(userid, ticket, attachmentid);
        }

        [WebMethod]
        public string emptyTrash(string userid, string ticket)
        {
            return new GetData().emptyTrash(userid, ticket);
        }


        [WebMethod]
        public string logout(string userid)
        {
            return new GetData().logout(userid);
        }
}

