﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Configuration;
using System.Data.Common;
using System.Data;
using System.Web;
using System.IO;
using System.Security.Cryptography;

namespace Jive.BusinessRules
{
    public class GetData
    { 
        // The database settings
        private static Database _db;
        // The database settings
        private static String DefaultQuota = "100000000";
        private static DateTime _dtdb = DateTime.Now.AddDays(-1);
        // The database settings
        private static readonly string _connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        private static readonly string _filePath = ConfigurationManager.ConnectionStrings["iCloudPath"].ConnectionString;
        private static readonly string _sitesfilePath = ConfigurationManager.ConnectionStrings["iCloudSites"].ConnectionString;
        private static readonly string _basefilePath = ConfigurationManager.ConnectionStrings["iCloudBase"].ConnectionString;


        // Creates the database or renews the connection after evry 2 hours
        private static void createDatabase()
        {
            System.TimeSpan diffResult = DateTime.Now.Subtract(_dtdb);
            if (diffResult.Hours > 2 || diffResult.Days >= 1)
            {
                // revalidate the database
                if (_db != null)
                {
                    // Close connection
                    _db.closeConnection();
                    _db = null;
                }
            }
            // If null, recreate
            if (_db == null)
            {
                _db = new Database(_connStr);
                _dtdb = DateTime.Now;
            }
            else
            {
                _dtdb = DateTime.Now;
            }
        }

        private void closeConn()
        {
            _db.closeConnection();
        }

        // Force a shutdown of connections
        public static void forceClose()
        {
            // revalidate the database
            try
            {
                if (_db != null)
                {
                    _db.closeConnection();
                    _db = null;
                }
            }
            catch
            {
            }
            _db = null;
        }

        public string getFilePath()
        {
            return _filePath;
        }

        public string getSiteFilePath()
        {
            return _sitesfilePath;
        }

        public string getBaseFilePath()
        {
            return _basefilePath;
        }

        // Executes an sql statement 
        public static void executeSQL(String sql)
        {
            createDatabase();
            string sql2 = _db.sanitize(sql);
            _db.ExecuteNonQuery(sql2, null);
        }

        public string TestConnection()
        {
            string retVal = "Unable to establish connection!!!";
            try
            {
                createDatabase();

                retVal = "Connection Established!!!";

            }
            catch (Exception ex)
            {
                retVal = "Unable to establish connection: " + ex.Message;
            }
            return retVal;
        }

        /// <summary>
        /// Based upon userid and password will provide ticket from users table
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="password"></param>
        /// <returns>ticket</returns>
        public string validateUser(string userid, string password)
        {
            string retVal = "<result>Invalid userid or password</result>";
            if (userid == null || password == null || userid == "" || password == "") 
            {
                retVal = "<result>userid or password cannot be empty</result>";
            }
            else
            {
                // Ensure that database has been created
                createDatabase();

                // Create the parameters list
                DbParameter[] param = { _db.getDbParameter("?username", userid), _db.getDbParameter("?password", password) };

                // Formulates the sql query
                string sql = _db.sanitize("SELECT username FROM jivedb.ofuser WHERE username = ?username and plainPassword = ?password;");

                // Reads the data set parameters

                object output = _db.ExecuteScalar(sql, param);

                // return true if record exists                
                if (output != null)
                {

                    retVal = "<result>" + getUpdateUserTicket(userid) + "</result>";
                }
                   
            }
            return retVal;
        }

        public string getUpdateUserTicket(string userid)
        {
            createDatabase();
            string retVal = "";
            // Create the parameters list

            DbParameter[] param = { _db.getDbParameter("?userid", userid) };

            // Formulates the sql query
            string sql = _db.sanitize("SELECT ticket FROM user WHERE userid = ?userid;");

            // Reads the data set parameters

            object output = _db.ExecuteScalar(sql, param);
            if (output != null && output.ToString() != "")
            {
                retVal = output.ToString();
            }
            else
            {
                string ticket = generateUserTicket(userid);
                DbParameter[] parameter = { _db.getDbParameter("?userid", userid), _db.getDbParameter("?ticket", ticket) };                
                sql = _db.sanitize("update user set ticket = ?ticket where userid = ?userid;");
                _db.ExecuteScalar(sql, parameter);
                retVal = ticket;
            }
            return retVal;

        }

        public string generateUserTicket(string data)
        {
             HMACSHA1 hash = new HMACSHA1();
             Random rnd = new Random();
             //consumersecrtet and tokensecret can be pulled from onfiguration if needed.
             hash.Key = Encoding.ASCII.GetBytes(string.Format("{0}&{1}",
                OAuthBase.UrlEncode("consumerSecret"), string.IsNullOrEmpty("tokenSecret")
                ? "" : OAuthBase.UrlEncode("tokenSecret")));
                return OAuthBase.ComputeHash(hash, data + rnd.Next(15000).ToString());
        }

        public bool validateUserTicket(string userid, string ticket)
        {
            createDatabase();
            DbParameter[] parameter = { _db.getDbParameter("?userid", userid), _db.getDbParameter("?ticket", ticket) };
            string sql = _db.sanitize("select ticket from user where ticket = ?ticket and userid = ?userid;");
            // string sql = _db.sanitize("select ticket from user where userid = ?userid;");
            object retVal = _db.ExecuteScalar(sql, parameter);
            if (retVal != null && retVal.ToString() != "")            
            {
                return true;
            }
            return false;


        }
        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="ticket"></param>
        /// <returns>Xml</returns>
        public string getUserInfo(string userid, string ticket)
        {
            if (!validateUserTicket(userid, ticket))
                return "";
            
            StringBuilder retVal = new StringBuilder();
            createDatabase();

            // Create the parameters list
            DbParameter[] param = { _db.getDbParameter("?userid", userid.ToLower()), _db.getDbParameter("?ticket", ticket) };

            // Formulates the sql query
            string sql = _db.sanitize("SELECT userid, fullname, quota FROM user WHERE userid = ?userid;");
            
            retVal.Append("<user>");
            string filepath = _filePath + userid + @"\";

            DirectoryInfo dirInfo = new DirectoryInfo(filepath);
            
            // Reads the data set parameters           
            using (DbDataReader reader = _db.ExecuteReader(sql, param))
            {
                while (reader.Read())
                {
                    retVal.Append("<name>" + reader["fullname"] + "</name>");
                    if (reader["quota"].ToString().Trim().Equals(""))
                    {
                        retVal.Append("<quota>" + DefaultQuota + "</quota>");
                    }
                    else
                    {
                        retVal.Append("<quota>" + reader["quota"] + "</quota>");
                    }
                    // do do system dir and get size;
                    retVal.Append("<used>" + getUserQuota(filepath) + "</used>");
                }
            }
            retVal.Append("</user>");

            return retVal.ToString();
        }

        public double getUserQuota(string path)
        {
            double fDirSize = 0;

            if (!System.IO.Directory.Exists(path))
                return fDirSize;
            try
            {
                System.IO.DirectoryInfo dirInfo = new
                System.IO.DirectoryInfo(path);


                System.IO.FileInfo[] oFiles = dirInfo.GetFiles();
                if (oFiles.Length > 0)
                {
                    int nFileLen = oFiles.Length;
                    for (int i = 0; i < nFileLen; i++)
                        fDirSize += oFiles[i].Length;
                }

                System.IO.DirectoryInfo[] oDirectories = dirInfo.GetDirectories();
                if (oDirectories.Length > 0)
                {
                    int nDirLen = oDirectories.Length;
                    for (int i = 0; i < nDirLen; i++)
                        fDirSize += getUserQuota(oDirectories[i].FullName);
                }
            }
            catch (Exception ex)
            {
                
            }

            return fDirSize;
        }

        public string getFolders(string userid, string ticket, string folderName, string returntype)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            StringBuilder retVal = new StringBuilder();

            retVal.Append("<result><items>");

            folderName = folderName.Trim();

            if (folderName.Equals(""))
            {
                ArrayList groups = getSites(userid);
                foreach (String groupname in groups)
                {
                    retVal.Append("<folder name='" + groupname + "'></folder>");
                }
                retVal.Append("<folder name='Personal'></folder>");
                retVal.Append("</items></result>");
                return retVal.ToString();
            }

            if (!folderName.EndsWith(@"\"))
                folderName = folderName + @"\";

            if (folderName.StartsWith("Personal"))
            {
                // This is for personal folders
                string filepath = _filePath + userid + @"\";

                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                if (!Directory.Exists(filepath + @"\Trash"))
                    Directory.CreateDirectory(filepath + @"\Trash");


                filepath = filepath + folderName.Substring(9);

                if (!Directory.Exists(filepath))
                {
                    retVal.Append("</items></result>");
                    return retVal.ToString();
                }

                if (returntype.ToLower() == "all" || returntype.ToLower() == "")
                {
                    DirectoryInfo di = new DirectoryInfo(filepath);
                    DirectoryInfo[] sdi = di.GetDirectories();
                    foreach (DirectoryInfo ssdi in sdi)
                    {
                        if (ssdi.Name == "Trash")
                        {
                        }
                        else
                        {
                            retVal.Append("<folder name='" + ssdi.Name + "' />");
                        }
                        // GetNestedFolder(ssdi.FullName, retVal, userid);
                        // retVal.Append("</folder>");
                    }
                    GetFilesForFolder(filepath, retVal);
                    retVal.Append("</items></result>");
                }
                else if (returntype.ToLower() == "file")
                {
                    FileInfo ffi = null;
                    foreach (string filePath in Directory.GetFiles(filepath))
                    {
                        ffi = new FileInfo(filePath);
                        retVal.Append("<file name='" + ffi.Name + "' mime='" + getMime(ffi.Extension) + "' size='" + ffi.Length + "' />");
                    }
                    retVal.Append("</items></result>");
                }
                else if (returntype.ToLower() == "folder")
                {
                    DirectoryInfo di = new DirectoryInfo(filepath);
                    DirectoryInfo[] sdi = di.GetDirectories();
                    foreach (DirectoryInfo ssdi in sdi)
                    {
                        if (ssdi.Name == "Trash")
                        {
                        }
                        else
                        {
                            retVal.Append("<folder name='" + ssdi.Name + "' />");
                        }
                        // retVal.Append("</folder>");
                    }
                    retVal.Append("</items></result>");
                }
                return retVal.ToString();
            }

            else 
            {
                string sitename = folderName.Substring(0, folderName.IndexOf(@"\"));

                if (!validSite(sitename))
                {
                    retVal.Append("</items></result>");
                    return retVal.ToString();
                }

                // This is for sites folders
                string filepath = _sitesfilePath + sitename + @"\";

                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                if (!Directory.Exists(filepath + @"\Trash"))
                    Directory.CreateDirectory(filepath + @"\Trash");

                filepath = _sitesfilePath + folderName;

                if (!Directory.Exists(filepath))
                {
                    retVal.Append("</items></result>");
                    return retVal.ToString();
                }

                if (returntype.ToLower() == "all" || returntype.ToLower() == "")
                {
                    DirectoryInfo di = new DirectoryInfo(filepath);
                    DirectoryInfo[] sdi = di.GetDirectories();
                    foreach (DirectoryInfo ssdi in sdi)
                    {
                        if (ssdi.Name == "Trash")
                        {
                        }
                        else
                        {
                            retVal.Append("<folder name='" + ssdi.Name + "' />");
                        }
                        // GetNestedFolder(ssdi.FullName, retVal, userid);
                        // retVal.Append("</folder>");
                    }
                    GetFilesForFolder(filepath, retVal);
                    retVal.Append("</items></result>");
                }
                else if (returntype.ToLower() == "file")
                {
                    FileInfo ffi = null;
                    foreach (string filePath in Directory.GetFiles(filepath))
                    {
                        ffi = new FileInfo(filePath);
                        retVal.Append("<file name='" + ffi.Name + "' mime='" + getMime(ffi.Extension) + "' size='" + ffi.Length + "' />");
                    }
                    retVal.Append("</items></result>");
                }
                else if (returntype.ToLower() == "folder")
                {
                    DirectoryInfo di = new DirectoryInfo(filepath);
                    DirectoryInfo[] sdi = di.GetDirectories();
                    foreach (DirectoryInfo ssdi in sdi)
                    {
                        if (ssdi.Name == "Trash")
                        {
                        }
                        else
                        {
                            retVal.Append("<folder name='" + ssdi.Name + "' />");
                        }
                        // retVal.Append("</folder>");
                    }
                    retVal.Append("</items></result>");
                }
                return retVal.ToString();
            }
        }

        public bool validSite(string site)
        {
            createDatabase();
            DbParameter[] parameter = { _db.getDbParameter("?class", site) };
            string sql = _db.sanitize("select id from class where class = ?class;");
            object retVal = _db.ExecuteScalar(sql, parameter);
            if (retVal != null && retVal.ToString() != "")
            {
                return true;
            }
            return false;
        }

        public ArrayList getSites(string userid)
        {
            createDatabase();
            DbParameter[] parameter = { _db.getDbParameter("?userid", userid) };
            string sql = _db.sanitize("select groupname from role where userid = ?userid;");
            ArrayList list = new ArrayList();
            using (IDataReader reader = _db.ExecuteReader(sql, parameter))
            {
                while (reader.Read())
                {
                    list.Add(reader["groupname"]);
                }
            }
            return list;
        }

        /*
        public string getAllFolders(string userid, string ticket, string folderName, string returntype)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            StringBuilder retVal = new StringBuilder();

            retVal.Append("<result><items>");

            string filepath = _filePath + userid + @"\";

            if (!Directory.Exists(filepath))
                Directory.CreateDirectory(filepath);

            if (!Directory.Exists(filepath + @"\Trash"))
                Directory.CreateDirectory(filepath + @"\Trash");

            if (!Directory.Exists(filepath + @"\Shared Folder"))
                Directory.CreateDirectory(filepath + @"\Shared Folder");

            filepath = filepath + folderName;

            if (!Directory.Exists(filepath))
            {
                retVal.Append("</items></result>");
                return retVal.ToString();
            }

            if (returntype.ToLower() == "all" || returntype.ToLower() == "")
            {
                DirectoryInfo di = new DirectoryInfo(filepath);
                DirectoryInfo[] sdi = di.GetDirectories();
                foreach (DirectoryInfo ssdi in sdi)
                {
                    if (ssdi.Name == "Shared Folder")
                    {
                        retVal.Append("<folder name='" + ssdi.Name + "' access='Shared'>");
                        if (checkSharedFolder(userid, di.Name + "\\" + ssdi.Name))
                        {
                            //make folder access to shared
                        }
                    }
                    else
                    {
                        retVal.Append("<folder name='" + ssdi.Name + "' >");
                    }
                    GetNestedFolder(ssdi.FullName, retVal, userid);
                    //GetFilesForFolder(ssdi.FullName, retVal);
                    retVal.Append("</folder>");
                }
                GetFilesForFolder(filepath, retVal);

                retVal.Append("</items></result>");
            }
            else if (returntype.ToLower() == "file")
            {
                FileInfo ffi = null;
                foreach (string filePath in Directory.GetFiles(filepath))
                {
                    ffi = new FileInfo(filePath);
                    retVal.Append("<file name='" + ffi.Name + "' mime='" + getMime(ffi.Extension) + "' size='" + ffi.Length + "' />");
                }
                retVal.Append("</items></result>");
            }
            else if (returntype.ToLower() == "folder")
            {
                DirectoryInfo di = new DirectoryInfo(filepath);
                DirectoryInfo[] sdi = di.GetDirectories();
                foreach (DirectoryInfo ssdi in sdi)
                {
                    if (ssdi.Name == "Shared Folder")
                    {
                        retVal.Append("<folder name='" + ssdi.Name + "' access='Shared'>");
                        if (checkSharedFolder(userid, di.Name + "\\" + ssdi.Name))
                        {
                            //make folder access to shared
                        }
                    }
                    else
                    {
                        retVal.Append("<folder name='" + ssdi.Name + "' >");
                    }
                    retVal.Append("</folder>");
                }
                retVal.Append("</items></result>");
            }
            return retVal.ToString();
        }
         * */

        public bool checkSharedFolder(string userid, string path)        
        {
            createDatabase();

            DbParameter[] parameter = { _db.getDbParameter("?userid", userid), _db.getDbParameter("?path", path) };
            string sql = _db.sanitize("select userid from sharedFolders userid = ?userid and path = ?path;");
            object retVal = _db.ExecuteScalar(sql, parameter);
            if (retVal != null && retVal.ToString() != "")            
            {
                return true;
            }
            return false;
        }

        public void GetNestedFolder(string filepath, StringBuilder retVal, string userid)
        {
            DirectoryInfo di = new DirectoryInfo(filepath);
            DirectoryInfo[] sdi = di.GetDirectories();
            foreach (DirectoryInfo ssdi in sdi)
            {
                if (ssdi.Name == "Shared Folder")
                {
                    retVal.Append("<folder name='" + ssdi.Name + "' access='Shared'>");
                    if (checkSharedFolder(userid, di.Name + "\\" + ssdi.Name))
                    {
                        //make folder access to shared
                    }
                }
                else
                    retVal.Append("<folder name='" + ssdi.Name + "' >");
                GetNestedFolder(ssdi.FullName, retVal, userid);
                retVal.Append("</folder>");
            }
            GetFilesForFolder(filepath, retVal);
        }

        public void GetFilesForFolder(string filepath, StringBuilder retVal)
        {
            DirectoryInfo di = new DirectoryInfo(filepath);
            FileInfo[] fi = di.GetFiles();
            foreach (FileInfo ffi in fi)
            {
                retVal.Append("<file name='" + ffi.Name + "' mime='" + getMime(ffi.Extension) + "' size='" + ffi.Length + "' />");
            }
        }

        public string getMime(string extension)
        {
            return extension;
        }

        public string getAllSharedResource(string userid, string ticket)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            StringBuilder retVal = new StringBuilder();          
            
            retVal.Append("<result><items>");

            createDatabase();
            ArrayList list = new ArrayList();
            DbParameter[] parameter = { _db.getDbParameter("?userid", userid), _db.getDbParameter("?uid", userid) };
            string sql = _db.sanitize("select * from sharedfolders where otheruser = ?userid or otheruser in (select groupname from role where userid = ?uid);");
            using (IDataReader reader = _db.ExecuteReader(sql, parameter))
            {
                while (reader.Read())
                {
                    bool skip = false;
                    String fpath = _filePath + reader["userid"] + @"\" + reader["path"];
                    String fpath2 = reader["userid"] + @"\" + reader["path"];
                    foreach (String str in list)
                    {
                        if (str.Equals(fpath))
                            skip = true;
                    }
                    if (!skip)
                    {
                        list.Add(fpath);

                        if (File.Exists(fpath))
                        {
                            FileInfo ffi = null;
                            ffi = new FileInfo(fpath);
                            retVal.Append("<file name='" + ffi.Name + "' mime='" + getMime(ffi.Extension) + "' size='" + ffi.Length + "' location'" + fpath2 + "' />");
                        }
                    }
                }
            }

            retVal.Append("</items></result>");
            return retVal.ToString();
        }


        public string createFolder(string userid, string ticket, string folderPath, string folderName)
        {
            if (!validateUserTicket(userid, ticket))
                return "";
            
            folderPath = folderPath.Trim();
            folderName = folderName.Trim();

            if (folderPath.Equals("") || folderName.Equals(""))
            {
                return "<result>false</result>";
            }

            if (!folderPath.EndsWith(@"\"))
                folderPath = folderPath + @"\";

            try
            {
                if (folderPath.Equals(""))
                {
                    return "<result>false</result>";
                }
                if (folderPath.StartsWith("Personal"))
                {
                    string filepath = _filePath + userid + @"\";

                    if (!Directory.Exists(filepath))
                        Directory.CreateDirectory(filepath);

                    filepath = filepath + folderPath.Substring(9)  + folderName;

                    if (!Directory.Exists(filepath))
                    {
                        if (folderName.ToLower() != "trash")
                        {
                            Directory.CreateDirectory(filepath);
                            return "<result>true</result>";
                        }
                    }
                }
                else
                {
                    // Are we an instructor in that class
                    string sitename = folderPath.Substring(0, folderPath.IndexOf(@"\"));

                    if (validSite(sitename)) {
                        if (isInstructor (userid, sitename)) {
                            string filepath = _sitesfilePath + sitename;

                            if (!Directory.Exists(filepath))
                                Directory.CreateDirectory(filepath);

                            filepath = _sitesfilePath + folderPath +  folderName;

                            if (!Directory.Exists(filepath))
                            {
                                if (folderName.ToLower() != "trash")
                                {
                                    Directory.CreateDirectory(filepath);
                                    return "<result>true</result>";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return "<result>false</result>";
        }

        public bool isInstructor(string userid, string site)
        {
            createDatabase();
            DbParameter[] parameter = { _db.getDbParameter("?userid", userid), _db.getDbParameter("?groupname", site) };
            string sql = _db.sanitize("select role from role where userid = ?userid and groupname = ?groupname;");
            bool retVal = false;
            using (IDataReader reader = _db.ExecuteReader(sql, parameter))
            {
                while (reader.Read())
                {
                    String role = reader["role"].ToString();
                    if (role.ToLower().Equals("teacher") || role.ToLower().Equals("instructor"))
                    {
                        retVal = true;
                    }
                }
            }
            return retVal;
        }

        public string deleteFolder(string userid, string ticket, string folderName)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            if (folderName.IndexOf(@"\") <= 0)
            {
                return "<result>false</result>";
            }

            folderName = folderName.Trim();

            if (folderName.Equals("") )
            {
                return "<result>false</result>";
            }

            if (folderName.StartsWith("Personal"))
            {
                try
                {
                    string lastFolderName = folderName.Substring(9);
                    if (folderName.Contains(@"\"))
                    {
                        lastFolderName = folderName.Substring(folderName.LastIndexOf(@"\") + 1);
                    }
                    string trashFilePath = _filePath + userid + @"\Trash\" + lastFolderName;
                    string filepath = _filePath + userid + @"\";

                    if (!Directory.Exists(filepath))
                        Directory.CreateDirectory(filepath);

                    filepath = filepath + folderName.Substring(9);

                    if (Directory.Exists(filepath))
                    {
                        string ftrashFile = trashFilePath;
                        int id = 1;
                        while (Directory.Exists(ftrashFile))
                        {
                            ftrashFile = trashFilePath + id;
                        }
                        Directory.Move(filepath, ftrashFile);
                        return "<result>true</result>";
                    }
                }
                catch (Exception ex)
                {
                }
            }
            else
            {
                try
                {
                    string sitename = folderName.Substring(0, folderName.IndexOf(@"\"));
                    if (validSite(sitename))
                    {
                        if (isInstructor(userid, sitename))
                        {
                            string lastFolderName = folderName;
                            if (folderName.Contains(@"\"))
                            {
                                lastFolderName = folderName.Substring(folderName.LastIndexOf(@"\") + 1);
                            }
                            string trashFilePath = _sitesfilePath + sitename + @"\Trash\" + lastFolderName;
                            string filepath = _sitesfilePath + sitename;

                            if (!Directory.Exists(filepath))
                                Directory.CreateDirectory(filepath);

                            filepath = _sitesfilePath + folderName;

                            if (Directory.Exists(filepath))
                            {
                                string ftrashFile = trashFilePath;
                                int id = 1;
                                while (Directory.Exists(ftrashFile))
                                {
                                    ftrashFile = trashFilePath + id;
                                }
                                Directory.Move(filepath, ftrashFile);
                                return "<result>true</result>";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }
            return "<result>false</result>";
        }

        public string deleteFile(string userid, string ticket, string filepath)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            filepath = filepath.Trim();
            if (filepath.IndexOf(@"\") <= 0)
            {
                return "<result>false</result>";
            }

            if (filepath.StartsWith("Personal"))
            {
                try
                {
                    string lastFileName = filepath.Substring(9);
                    if (filepath.Contains(@"\"))
                    {
                        lastFileName = filepath.Substring(filepath.LastIndexOf(@"\") + 1);
                    }
                    string trashFilePath = _filePath + userid + @"\Trash\" + lastFileName;

                    if (File.Exists(trashFilePath))
                        File.Delete(trashFilePath);

                    string filepaths = _filePath + userid + @"\";

                    if (!Directory.Exists(filepaths))
                        Directory.CreateDirectory(filepaths);

                    filepaths = filepaths + filepath.Substring(9);

                    if (File.Exists(filepaths))
                    {
                        string ftrashFilePath = trashFilePath;
                        if (File.Exists(ftrashFilePath))
                            File.Delete(ftrashFilePath);
                        File.Move(filepaths, ftrashFilePath);
                        return "<result>true</result>";
                    }
                }
                catch (Exception ex)
                {
                }
            }
            else
            {
                try
                {
                    string sitename = filepath.Substring(0, filepath.IndexOf(@"\"));
                    if (validSite(sitename))
                    {
                        if (isInstructor(userid, sitename))
                        {
                            string lastFileName = filepath;
                            if (filepath.Contains(@"\"))
                            {
                                lastFileName = filepath.Substring(filepath.LastIndexOf(@"\") + 1);
                            }
                            string trashFilePath = _sitesfilePath + sitename + @"\Trash\" + lastFileName;

                            if (File.Exists(trashFilePath))
                                File.Delete(trashFilePath);

                            string filepaths = _sitesfilePath + sitename + @"\";

                            if (!Directory.Exists(filepaths))
                                Directory.CreateDirectory(filepaths);

                            filepaths = _sitesfilePath + filepath;

                            if (File.Exists(filepaths))
                            {
                                string ftrashFilePath = trashFilePath;
                                if (File.Exists(ftrashFilePath))
                                    File.Delete(ftrashFilePath);
                                File.Move(filepaths, ftrashFilePath);
                                return "<result>true</result>";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }
            return "<result>false</result>";
        }

        public string emptyTrash(string userid, string ticket)
        {
            if (!validateUserTicket(userid, ticket))
                return "";
            string filepaths = _filePath + userid + @"\Trash";

            if (Directory.Exists(filepaths))
            {
                Directory.Delete(filepaths, true);
                Directory.CreateDirectory(filepaths);
                return "true";
            }
            return "false";
        }

        /*
        public string shareResource(string userid, string ticket, string filePath, string otherusers)
        {
            if (!validateUserTicket(userid, ticket))
            {
                createDatabase();
                
				string sql = "";
				DbParameter[] param = { _db.getDbParameter("?userid", userid), 
										  _db.getDbParameter("?filePath", filePath)};   
				
				sql = "insert into sharedfolders(userid, path) values (?userid, ?filePath);";
				
				int retVal = _db.ExecuteNonQuery(sql, param);

				if (retVal > 0)
				{
					return "<result>true</result>";
				}				
            }
            return "<result>false</result>";  
        }
         * */

        public string shareResource(string userid, string ticket, string filePath, string otherusers)
        {
            if (validateUserTicket(userid, ticket))
            {
                // we only share personal files
                if (!filePath.StartsWith("Personal"))
                {
                    return "<result>false</result>";
                }
                createDatabase();
                string sql = "";
                DbParameter[] param = { _db.getDbParameter("?userid", userid),
                        _db.getDbParameter("?filePath", filePath.Substring(9)),
                        _db.getDbParameter("?otherusers", otherusers)
                                      };

                sql = "select count(*) sharedfolders where userid=?userid and path=?filePath and otheruser=?otherusers ;";
                int retVal = (int)_db.ExecuteScalar(sql, param);
                if (retVal > 0)
                {
                    return "<result>true</result>";
                }

                sql = "insert into sharedfolders(userid, path, otheruser) values (?userid, ?filePath, ?otherusers);";

                retVal = _db.ExecuteNonQuery(sql, param);

                if (retVal > 0)
                {
                    return "<result>true</result>";
                }
            }
            return "<result>false</result>";
        }

        public string copyFile(string userid, string ticket, string srcFile, string destFolder)
        {
            if (validateUserTicket(userid, ticket))
            {
                srcFile = srcFile.Trim();
                destFolder = destFolder.Trim();
                string srcFilePath = srcFile;
                string destFilePath = destFolder;

                if (srcFile.Equals("") || destFolder.Equals(""))
                {
                    return "<result>false</result>";
                }
                if (!destFolder.EndsWith(@"\"))
                    destFolder = destFolder + @"\";

                if (srcFile.StartsWith("Personal"))
                {
                    srcFilePath = _filePath + userid + @"\" + srcFile.Substring(9);
                }
                else
                {
                    srcFilePath = _sitesfilePath + srcFile;
                }

                if (!File.Exists(srcFilePath))
                {
                    return "<result>false</result>";
                }


                if (destFolder.StartsWith("Personal"))
                {
                    destFilePath = _filePath + userid + @"\" + destFolder.Substring(9);
                }
                else
                {
                    destFilePath = _sitesfilePath + destFolder;
                    string sitename = destFolder.Substring(0, destFolder.IndexOf(@"\"));
                    if (validSite(sitename))
                    {
                        if (isInstructor(userid, sitename))
                        {
                            destFilePath = _sitesfilePath + destFolder;
                        }
                        else
                        {
                            return "<result>false</result>";
                        }
                    }
                    else
                    {
                        return "<result>false</result>";
                    }
                }

                if (File.Exists(destFilePath))
                {
                    return "<result>false</result>";
                }

                FileInfo ffi = new FileInfo(srcFilePath);
                File.Copy(srcFilePath, destFilePath + @"\" + ffi.Name);
                return "<result>true</result>";
            }
            return "<result>false</result>";
        }

        public string moveFile(string userid, string ticket, string srcFile, string destFolder)
        {
            if (validateUserTicket(userid, ticket))
            {
                srcFile = srcFile.Trim();
                destFolder = destFolder.Trim();
                string srcFilePath = srcFile;
                string destFilePath = destFolder;

                if (srcFile.Equals("") || destFolder.Equals(""))
                {
                    return "<result>false</result>";
                }
                if (!destFolder.EndsWith(@"\"))
                    destFolder = destFolder + @"\";

                if (srcFile.StartsWith("Personal"))
                {
                    srcFilePath = _filePath + userid + @"\" + srcFile.Substring(9);
                }
                else
                {
                    srcFilePath = _sitesfilePath + srcFile;
                }

                if (!File.Exists(srcFilePath))
                {
                    return "<result>false</result>";
                }


                if (destFolder.StartsWith("Personal"))
                {
                    destFilePath = _filePath + userid + @"\" + destFolder.Substring(9);
                }
                else
                {
                    destFilePath = _sitesfilePath + destFolder;
                    string sitename = destFolder.Substring(0, destFolder.IndexOf(@"\"));
                    if (validSite(sitename))
                    {
                        if (isInstructor(userid, sitename))
                        {
                            destFilePath = _sitesfilePath + destFolder;
                        }
                        else
                        {
                            return "<result>false</result>";
                        }
                    }
                    else
                    {
                        return "<result>false</result>";
                    }
                }

                if (!Directory.Exists(destFilePath))
                {
                    Directory.CreateDirectory(destFilePath);
                }

                FileInfo ffi = new FileInfo(srcFilePath);
                if (File.Exists(destFilePath + @"\" + ffi.Name))
                {
                    return "<result>false</result>";
                }

                File.Move(srcFilePath, destFilePath + @"\" + ffi.Name);
                return "<result>true</result>";
            }
            return "<result>false</result>";
        }

        public string copySharedFile(string userid, string ticket, string srcFile)
        {
            if (validateUserTicket(userid, ticket))
            {
                srcFile = srcFile.Trim();
                string srcFilePath = srcFile;
                srcFilePath = _filePath + srcFile;

                // To ensure we have access to this file

                if (!File.Exists(srcFilePath))
                {
                    return "<result>false</result>";
                }


                string destFilePath = _filePath + userid + @"\Uploads";

                if (!Directory.Exists(destFilePath))
                    Directory.CreateDirectory(destFilePath);

                FileInfo fi = new FileInfo(srcFilePath);
                destFilePath = destFilePath + @"\" + fi.Name;
                if (File.Exists(destFilePath))
                {
                    return "<result>false</result>";
                }
                File.Copy(srcFilePath, destFilePath);
                return "<result>true</result>";
            }
            return "<result>false</result>";
        }

    
        public string markPrivate(string userid, string ticket, string reflectionid)
        {
            if (validateUserTicket(userid, ticket))
            {
                createDatabase();
				string sql = "";
				DbParameter[] param = { _db.getDbParameter("?userid", userid), 
										  _db.getDbParameter("?reflectionid", reflectionid)};   
				sql = "Update reflection set access ='Private' where userid=?userid and reflectionid= ?reflectionid";
				int retVal = _db.ExecuteNonQuery(sql, param);
				if (retVal > 0)
				{
					return "<result>true</result>";
				}				
            }
            return "<result>false</result>";  
        }
      
        public string getReflectionsSummary(string userid, string ticket, string monthyear, bool isPublic)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            createDatabase();
            string sql="";
            if(isPublic==true)
            {
				sql = "select r.reflectionid, r.userid, title, createddate, access, content, isdeleted, " + 
                      "count(c.reflectioncommentid) as comments, if (AVG(rating) IS NULL, 0, AVG(rating)) as averating " + 
                      "from reflection r " + 
                      "LEFT JOIN reflectioncomment c " + 
                      "on c.reflectionid = r.reflectionid " + 
                      "where year(createddate) = ?year and Month(createddate) = ?mth and " + 
                      "isdeleted = 0 and r.userid = ?userid and access = 'Public' " + 
                      "group by reflectionid ";
           }
           else
           {
               sql = "select r.reflectionid, r.userid, title, createddate, access, content, isdeleted, " +
                      "count(c.reflectioncommentid) as comments, if (AVG(rating) IS NULL, 0, AVG(rating)) as averating " +
                     "from reflection r " +
                     "LEFT JOIN reflectioncomment c " +
                     "on c.reflectionid = r.reflectionid " +
                      "where year(createddate) = ?year and Month(createddate) = ?mth and " +
                     "isdeleted = 0 and r.userid = ?userid " +
                     "group by reflectionid ";
           }

            DbParameter[] param = { _db.getDbParameter("?year", monthyear.Substring(0, 4)), _db.getDbParameter("?mth", monthyear.Substring(4, 2)), _db.getDbParameter("?userid", userid) };

            StringBuilder retVal = new StringBuilder();
            retVal.Append("<result><reflections>");
            using (IDataReader reader = _db.ExecuteReader(sql, param))
            {
                while (reader.Read())
                {
                    retVal.Append("<reflection>");
                    retVal.Append("<id>" + reader["reflectionid"] + "</id>");
                    retVal.Append("<title>" + reader["title"] + "</title>");
                    retVal.Append("<date>" + reader["createddate"] + "</date>");
                    retVal.Append("<access>" + reader["access"] + "</access>");
                    retVal.Append("<comments>" + reader["comments"] + "</comments>");
                    retVal.Append("<rating>" + reader["averating"] + "</rating>");
                    // retVal.Append("<reflectiondata >" + reader["data"] + "</reflectiondata>");
                    retVal.Append("</reflection>");
                }
            }
            retVal.Append("</reflections></result>");

            return retVal.ToString();
        }

        /// <summary>
        /// Get Reflection correspoding to userid and reflectionid
        /// </summary>
        /// <param name="userid">UserId</param>
        /// <param name="reflectionid">ReflectionId</param>
        /// <returns>XML</returns>
        public string getReflection(string userid, string ticket, string reflectionid, string ispublic)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            createDatabase();
            string sql = "select r.reflectionid, r.userid, title, createddate, access, content, isdeleted, " +
                   "count(c.reflectioncommentid) as comments, if (AVG(rating) IS NULL, 0, AVG(rating)) as averating " +
                  "from reflection r " +
                  "LEFT JOIN reflectioncomment c " +
                  "on c.reflectionid = r.reflectionid " +
                   "where " +
                  "isdeleted = 0 and r.reflectionid = ?reflectionid and r.userid = ?userid " +
                  "group by reflectionid ";
            if (ispublic.ToLower() == "true" || ispublic.ToLower() == "1")
            {
                sql = "select r.reflectionid, r.userid, title, createddate, access, content, isdeleted, " +
                       "count(c.reflectioncommentid) as comments, if (AVG(rating) IS NULL, 0, AVG(rating)) as averating " +
                      "from reflection r " +
                      "LEFT JOIN reflectioncomment c " +
                      "on c.reflectionid = r.reflectionid " +
                       "where access = 'Public' and " +
                      "isdeleted = 0 and r.reflectionid = ?reflectionid and r.userid = ?userid " +
                      "group by reflectionid ";
            }


            DbParameter[] param = { _db.getDbParameter("?reflectionid", reflectionid), _db.getDbParameter("?userid", userid) };

            StringBuilder retVal = new StringBuilder();
            retVal.Append("<result><reflections>");
            using (IDataReader reader = _db.ExecuteReader(sql, param))
            {
                while (reader.Read())
                {
                    retVal.Append("<reflection>");
                    retVal.Append("<id>" + reader["reflectionid"] + "</id>");
                    retVal.Append("<title>" + reader["title"] + "</title>");
                    retVal.Append("<date>" + Convert.ToString(reader["createddate"]) + "</date>");
                    retVal.Append("<access>" + reader["access"] + "</access>");
                    retVal.Append("<reflectiondata >" + reader["content"] + "</reflectiondata>");
                    retVal.Append("<comments>" + reader["comments"] + "</comments>");
                    retVal.Append("<rating>" + reader["averating"] + "</rating>");
                    retVal.Append("</reflection>");
                }
            }
            retVal.Append("</reflections></result>");

            return retVal.ToString();
        }

        /// <summary>
        /// Insert/Update Relection
        /// </summary>
        /// <param name="userid">UserId</param>
        /// <param name="id">ReflectionId</param>
        /// <param name="datetime">DateTime</param>
        /// <param name="title">Reflection Title</param>
        /// <param name="content">Reflection Data</param>
        /// <returns>XML</returns>
        public string saveReflection(string userid, string ticket, string id, string title, string content, bool isPrivate)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            createDatabase();

            string sql = "";
            string access = "Private";
            if (!isPrivate) access = "Public";


            DbParameter[] param = { _db.getDbParameter("?userid", userid), 
                                      _db.getDbParameter("?title", title),
                                      _db.getDbParameter("?content", content),
                                      _db.getDbParameter("?access", access),
                                      _db.getDbParameter("?id", id)};

            if (id == "" || id == null || id == "0")
            {
                //insert
                sql = "insert into reflection(userid, title, createddate, content, access, isdeleted) values (?userid, ?title, now(), ?content, ?access, 0); select LAST_INSERT_ID();";
                object retVal = _db.ExecuteScalar(sql, param);
                if (retVal != null)
                {
                    return "<result>" + retVal + "</result>";
                }
            }
            else
            {
                //update
                sql = "update reflection set userid = ?userid, title = ?title, content = ?content, access = ?access " +
                       " where reflectionid = ?id ; ";
                _db.ExecuteNonQuery(sql, param);
                return "<result>" + id + "</result>";
            }
            return "<result>" + 0 + "</result>";
        }

        /// <summary>
        /// Delete Reflection
        /// </summary>
        /// <param name="userid">UserId</param>
        /// <param name="reflectionid">ReflectionId</param>
        /// <returns>XML</returns>
        public string deleteReflection(string userid, string ticket, int reflectionid)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            createDatabase();
            string sql = "update reflection set isdeleted = 1 where reflectionid = ?reflectionid ;";

            DbParameter[] param = { _db.getDbParameter("?reflectionid", reflectionid) };

            int retVal = _db.ExecuteNonQuery(sql, param);

            if (retVal > 0)
            {
                return "<result>true</result>";
            }
            return "<result>false</result>";
        }


        public string saveReflectionAttachment(string userid, string ticket, string reflectionid, string name, string guid)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            string sql = "insert into reflectionattachment(reflectionid, attachmentguid, attachmentname) " +
                           "values ( ?reflectionid, ?attachmentguid, ?attachmentname  ) ;" +
                           " select LAST_INSERT_ID(); ";
            createDatabase();

            DbParameter[] param = { _db.getDbParameter("?reflectionid", reflectionid), 
                                       _db.getDbParameter("?attachmentguid", guid),
                                       _db.getDbParameter("?attachmentname", name)};

            object retVal = _db.ExecuteScalar(sql, param);

            if (retVal != null)
            {
                return "<result>" + retVal + "</result>";
            }
            return "<result>0</result>";
        }

        public string deleteReflectionAttachment(string userid, string ticket, string attachmentid)
        {
            if (!validateUserTicket(userid, ticket))
                return "";

            createDatabase();
            string fileName = "";
            DbParameter[] param = {
            _db.getDbParameter("?relectionattachmentid", attachmentid) };
            fileName = getReflectionAttachmentById(attachmentid);
            String fullpath = getBaseFilePath() + @"system\reflection\" + fileName;
            string sql = "Delete from reflectionattachment where reflectionattachmentid = ?relectionattachmentid; ";
            int retVal = _db.ExecuteNonQuery(sql, param);

            if (retVal > 0)
            {
                if (File.Exists(fullpath))
                    File.Delete(fullpath);
                return "<result>true</result>";
            }
            return "<result>false</result>";

        }

        public string getReflectionAttachmentById(string attachmentid)
        {
            createDatabase();
            string sql = _db.sanitize("select attachmentguid from reflectionattachment where reflectionattachmentid = ?attachmentid;");

            DbParameter[] param = { _db.getDbParameter("?attachmentid", attachmentid) };
            object retVal = _db.ExecuteScalar(sql, param);

            if (retVal != null && retVal.ToString() != "")
            {
                return retVal.ToString();
            }
            return "";
        }

        /// <summary>
        /// Get Reflection Comment and Attachments
        /// </summary>
        /// <param name="userid">UserId</param>
        /// <param name="reflectionid">ReflectionId</param>
        /// <returns>XML</returns>
        public string getReflectionComment(string userid, string ticket, string reflectionid)
        {
            if (!validateUserTicket(userid, ticket))
                return "";
            StringBuilder retVal = new StringBuilder();
            createDatabase();
            string sql = " select reflectioncommentid, reflectionid, userid, createddate, comment, rating from  reflectioncomment " +
                           "where isdeleted = 0 and reflectionid = ?reflectionid and userid = ?userid ;";

            DbParameter[] param = { _db.getDbParameter("?reflectionid", reflectionid), _db.getDbParameter("?userid", userid) };

            DataSet ds = _db.ExecuteDataSet(sql, param, "");

            retVal.Append("<result>");
            retVal.Append("<comments>");
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                retVal.Append("<comment>");
                retVal.Append("<userid>" + row["userid"] + "</userid>");
                retVal.Append("<comment>" + row["comment"] + "</comment>");
                retVal.Append("<rating>" + row["rating"] + "</rating>");
                retVal.Append("<createddate>" + row["createddate"] + "</createddate>");
                GetReflectionAttachment(reflectionid, retVal, userid);
                retVal.Append("</comment>");
            }
            retVal.Append("</comments>");
            retVal.Append("</result>");

            return retVal.ToString();
        }

        public void GetReflectionAttachment(string reflectionid, StringBuilder retVal, string userid)
        {
            createDatabase();
            string sql = "select ra.relectionattachmentid, ra.attachmentname, ra.attachmentguid " +
                            "from reflectionattachment ra inner join reflection r on r.reflectionid = ra.reflectionid " +
                            "where ra.reflectionid = ?reflectionid and r.userid = ?userid and r.isdeleted = 0 ";

            DbParameter[] param = { _db.getDbParameter("?reflectionid", reflectionid), _db.getDbParameter("?userid", userid) };

            DataSet ds = _db.ExecuteDataSet(sql, param, "");

            retVal.Append("<attachments>");
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                retVal.Append("<attachment>");
                retVal.Append("<attachmentid>" + row["relectionattachmentid"] + "</attachmentid>");
                retVal.Append("<attahcmentname>" + row["attachmentname"] + "</attachmentname>");
                retVal.Append("<attahcmentguid>" + row["attachmentguid"] + "</attachmentguid>");
                retVal.Append("</attachment>");
            }
            retVal.Append("</attachments>");
        }

        /// <summary>
        /// Insert/Update Reflection Comment
        /// </summary>
        /// <param name="reflectionid">Reflection Id</param>
        /// <param name="reflectioncommentid">Reflection CommentId for Update</param>
        /// <param name="userid">UserId</param>
        /// <param name="content">Content</param>
        /// <returns>XML</returns>
        public string addReflectionComment(string reflectionid, string reflectioncommentid, string userid, string ticket, string content)
        {
            if (!validateUserTicket(userid, ticket))
                return "";
            createDatabase();
            string sql = "";

            DbParameter[] param = { _db.getDbParameter("?reflectionid", reflectionid), 
                                      _db.getDbParameter("?reflectioncommentid", reflectioncommentid),
                                      _db.getDbParameter("?userid", userid), 
                                      _db.getDbParameter("?date", Convert.ToString(DateTime.Now)),                                      
                                      _db.getDbParameter("?comment", content)};

            if (reflectioncommentid == "" || reflectioncommentid == null || reflectioncommentid == "0")
            {
                sql = "insert into reflectioncomment(reflectionid, userid, createddate, comment) " +
                         " values (?reflectionid, ?userid, now(), ?comment);" +
                         "  select LAST_INSERT_ID(); ";
            }
            else
            {
                sql = "update reflectioncomment set reflectionid = ?reflectionid, userid = ?userid, comment = ?comment " +
                        " where reflectioncommentid = ?reflectioncommentid ;" +
                        " select ?reflectioncommentid as reflectioncommentid; ";
            }

            object retV = _db.ExecuteScalar(sql, param);

            if (retV != null)
            {
                return "<result>" + retV + "</result>";
            }
            return "<result>0</result>";
        }

        /// <summary>
        /// Delete Reflection Comments
        /// </summary>
        /// <param name="userid">UserId</param>
        /// <param name="commentid">Reflection Comment Id</param>
        /// <returns>XML</returns>
        public string deleteReflectionComment(string userid, string ticket, string commentid)
        {
            if (!validateUserTicket(userid, ticket))
                return "";
            createDatabase();
            string sql = "update reflectioncomment set isdeleted = 1 where reflectioncommentid = ?reflectioncommentid;";
            DbParameter[] param = { _db.getDbParameter("?reflectioncommentid", commentid) };

            int retVal = _db.ExecuteNonQuery(sql, param);

            if (retVal > 0)
            {
                return "<result>true</result>";
            }
            return "<result>false</result>";
        }

        /// <summary>
        /// Insert ReflectionCommentAttachment
        /// </summary>
        /// <param name="userid">UserId</param>
        /// <param name="filename">FileName</param>
        /// <param name="commentid">ReflectionCommentId</param>
        /// <returns>XML</returns>
        public string saveReflectionCommentAttachment(string userid, string ticket, string commentid, string name, string guid)
        {
            if (!validateUserTicket(userid, ticket))
                return "";
            createDatabase();
            DbParameter[] param = { _db.getDbParameter("?reflectioncommentid", commentid),
                                       _db.getDbParameter("?attachmentguid", guid),
                                        _db.getDbParameter("?attachmentname", name)
                                  };

            string sql = "insert into reflectioncommentattachment(reflectioncommentid, attachmentguid, attachmentname) " +
                          " values(?reflectioncommentid, ?attachmentguid, ?attachmentname)";

            int retVal = _db.ExecuteNonQuery(sql, param);

            if (retVal > 0)
            {
                return "<result>true</result>";
            }
            return "<result>false</result>";
        }
        
        public string logout(string userid)
        {
			 createDatabase();
                
				string sql = "";
				DbParameter[] param = { _db.getDbParameter("?userid", userid)};   
				
				sql = "Update user set ticket ='' where userid=?userid;";
				
				int retVal = _db.ExecuteNonQuery(sql, param);

				if (retVal > 0)
				{
					return "<result>true</result>";
				}		
            return "<result>false</result>";
        }
    }
}
